package Project;

public class Thread {
	public void run()
	   {
	     System.out.println("concurrent Thread started running..");
	 }
	   public static void main( String args[] )
	   {
	     Thread mt = new Thread();
	     mt.start();
	   }
	  private void start() {
	   System.out.println("Thread Loading..");
	  }
	public static Object currentThread() {
		// TODO Auto-generated method stub
		return null;
	}
	 }


